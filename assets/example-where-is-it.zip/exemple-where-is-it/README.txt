L'ensemble des fichiers de ce répertoire ont été rassemblées par Didier Schwab (didier.schwab@univ-grenoble-alpes.fr)

Le fichier questions.csv a été écrit par Didier Schwab (didier.schwab@univ-grenoble-alpes.fr)

Les pictogrammes viennent du Portail Aragonais de la Communication Améliorée et Alternative, l'ARASAAC (http://www.arasaac.org)

Les images viennent du site Pixabay (https://pixabay.com)

Les sons ont été synthétisés par Amazon Polly (https://aws.amazon.com/fr/polly/)

------------------------------------------- Condition d'utilisation Pictogrammes -------------------------------------------
voir http://www.arasaac.org/condiciones_uso.php

Les fichiers originaux sont la propriété de la Députation Générale d'Aragon. 

Les ressources offertes sur ce site (pictogrammes, images ou vidéos), tout comme les Matériels élaborés à partir de ceux-ci sont publiés sous la Licence Creative Commons(BY-NC-SA), autorisant leur usage à DES FINS NON LUCRATIVES et tant que la source et l'auteur sont cités et se partagent sous la même licence.
Cela implique que toute oeuvre dérivée élaborée à partir des ressources contenues dans les catalogues d'ARASAAC (pictogrammes, images et vidéos), doit être distribuée avec la même licence Creative Commons (BY-NC-SA), l'auteur des pictogrammes doit être cité (Sergio Palao), ainsi que leur provenance (ARASAAC http://catedu.es/arasaac) et la licence sous laquelle ils sont distribués (Creative Commons). Voici quelques exemples de citation :
Les symboles pictographiques utilisés sont la propriété de CATEDU (http://catedu.es/arasaac/) sous licence Creative Commons et ont été créés par Sergio Palao
Les symboles utilisés sont l'oeuvre de Sergio Palao pour CATEDU (http://catedu.es/arasaac/) qui les publie sous licence Creative Commons
ou de manière schématique:
Auteur des pictogrammes : Sergio Palao Provenance: ARASAAC (http://catedu.es/arasaac/) Licence: CC (BY-NC-SA)

Clause d'extension de responsabilité:

Le Portail Aragonais des Systèmes de Communicacion Améliorée et Alternative a un caractère divulgatoire et orientatoire, et met à disposition de toute personne intéressée des informations sur le projet. Cependant, il faut préciser les points suivants :
L'information donnée est simplement informative et n'a pas de lien avec l'Administration, c'est pour cela qu'aucune responsabilité n'est endossée vis-à-vis de son contenu.
L'information disponible pourrait ne pas être exhaustive, ni exacte ou actualisée.
Des liens vers des pages externes sont mis à disposition, mais ARASAAC n'a aucun contrôle sur celles-ci, et décline toute responsabilité vis-à-vis de celles-ci.

------------------------------------------- Condition d'utilisation Images -------------------------------------------
https://pixabay.com/fr/service/terms/#usage

Use of the Service

In connection with your use of the Service you will not engage in or use any data mining, robots, scraping or similar data gathering or extraction methods. The technology and software underlying the Service or distributed in connection therewith is the property of Pixabay and our licensors, affiliates and our partners. You agree not to copy, modify, create a derivative work of, reverse engineer, reverse assemble or otherwise attempt to discover any source code, sell, assign, sublicense, or otherwise transfer any right in such technology or software. Any rights not expressly granted herein are reserved by Pixabay.

Large scale copying of Content is prohibited except as expressly authorized by Pixabay. To be clear, this applies to all Content, including Content made available as part of the public domain. The Service is protected by copyright as a collective work and/or compilation, pursuant to copyright laws, international conventions, and other intellectual property laws.

Using Images and Videos

Images and Videos on Pixabay are released under Creative Commons CC0. To the extent possible under law, uploaders of Pixabay have waived their copyright and related or neighboring rights to these Images and Videos. You are free to adapt and use them for commercial purposes without attributing the original author or source. Although not required, a link back to Pixabay is appreciated.

Please be aware:

a) Images and Videos may not be used in a way that shows identifiable persons in a disgraceful light, or to imply endorsement of products and services by depicted persons, brands, and organisations - unless permission was granted.

b) Certain Images or Videos may be subject to additional copyrights, property rights, trademarks etc. and may require the consent of a third party or the license of these rights.

À propos de Creative Commons CC0 (https://creativecommons.org/publicdomain/zero/1.0/deed.fr)

Pas de droit d’auteur

 Cette licence est acceptable pour des œuvres culturelles libres.
La personne qui a associé une œuvre à cet acte a dédié l’œuvre au domaine public en renonçant dans le monde entier à ses droits sur l’œuvre selon les lois sur le droit d’auteur, droit voisin et connexes, dans la mesure permise par la loi.

Vous pouvez copier, modifier, distribuer et représenter l’œuvre, même à des fins commerciales, sans avoir besoin de demander l’autorisation. Voir d’autres informations ci-dessous.
Autres informations
Les brevets et droits de marque commerciale qui peuvent être détenus par autrui ne sont en aucune façon affectés par CC0, de même pour les droits que pourraient détenir d’autres personnes sur l’œuvre ou sur la façon dont elle est utilisée, comme le droit à l’image ou à la vie privée.
À moins d’une mention expresse contraire, la personne qui a identifié une œuvre à cette notice ne concède aucune garantie sur l’œuvre et décline toute responsabilité de toute utilisation de l’œuvre, dans la mesure permise par la loi.
Quand vous utilisez ou citez l’œuvre, vous ne devez pas sous-entendre le soutien de l’auteur ou de la personne qui affirme.

https://creativecommons.org/publicdomain/zero/1.0/deed.fr